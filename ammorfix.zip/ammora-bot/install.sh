#!/usr/bin/env bash
# Install Ammora Daily Bot (Linux/Mac)
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js belum terpasang. Install dulu: https://nodejs.org"
  exit 1
fi
npm install
[ -f .env ] || cp .env.example .env
echo ""
echo "Selesai! Sekarang edit file .env (isi PRIVATE_KEY_1 dst) lalu jalankan:"
echo "  npm start       # sekali jalan"
echo "  npm run loop    # otomatis harian"
