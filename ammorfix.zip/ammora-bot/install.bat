@echo off
REM Install Ammora Daily Bot (Windows)
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js belum terpasang. Install dulu dari https://nodejs.org lalu jalankan ulang file ini.
  pause
  exit /b 1
)
call npm install
if not exist .env copy .env.example .env
echo.
echo Selesai! Edit file .env (isi PRIVATE_KEY_1 dst) lalu jalankan:
echo   npm start        ^& sekali jalan
echo   npm run loop     ^& otomatis harian
pause
