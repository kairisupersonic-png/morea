export function log(tag, w, ...args) {
  console.log(`[${new Date().toISOString()}] [${tag}] #${w.index} ${w.address.slice(0, 8)}... :: ${args.join(" ")}`);
}
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function nextUtcMidnight() {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.getTime() + 60_000 + Math.floor(Math.random() * 120_000); // 00:01-00:03 UTC
}
export function todayUTC() {
  return new Date().toISOString().slice(0, 10);
}
