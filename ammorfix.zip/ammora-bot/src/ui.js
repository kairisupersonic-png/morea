/* Tampilan terminal: warna + tabel ringkasan. Tidak ada dependensi. */
const C = process.stdout.isTTY || process.env.FORCE_COLOR
  ? { g: "\x1b[32m", r: "\x1b[31m", y: "\x1b[33m", c: "\x1b[36m", b: "\x1b[36m\x1b[1m", d: "\x1b[90m", B: "\x1b[1m", x: "\x1b[0m" }
  : { g: "", r: "", y: "", c: "", b: "", d: "", B: "", x: "" };
const pad = (s, n) => String(s).padEnd(n);
const trunc = (s, n) => (String(s).length <= n ? String(s) : String(s).slice(0, n - 1) + "…");

export const ui = {
  ok: (s) => `${C.g}${s}${C.x}`,
  err: (s) => `${C.r}${s}${C.x}`,
  warn: (s) => `${C.y}${s}${C.x}`,
  dim: (s) => `${C.d}${s}${C.x}`,
  walletTag: (w) => `${C.b}[#${w.index}]${C.x} ${w.address.slice(0, 8)}…`,
  tx: (label, hash) => console.log(`${C.d}  tx${C.x} ${pad(label, 18)} ${C.c}${hash}${C.x}`),
  verifyOk: (label, attempt, r) => console.log(`  ${C.g}✔ verify${C.x} ${pad(label, 18)} ${C.d}(percobaan ${attempt})${C.x} ${JSON.stringify(r).slice(0, 120)}`),
  verifyFail: (label, attempt, code, msg) => console.log(`  ${C.y}⟳ verify${C.x} ${pad(label, 18)} attempt ${attempt}: ${C.y}${code}${C.x} ${(msg ?? "").slice(0, 120)}`),
  banner(n, swapN, swapAmt, vaultAmt, stakeAmt) {
    const W = 54;
    const row = (s) => `${C.b}║${C.x}  ${pad(s, W - 4)}${C.b}║${C.x}`;
    console.log(`\n${C.b}╔${"═".repeat(W)}╗${C.x}`);
    console.log(row(`${C.B}AMMORA SEASON 2 — DAILY BOT${C.x}`));
    console.log(`${C.b}╠${"═".repeat(W)}╣${C.x}`);
    console.log(row(`${C.d}wallet${C.x} : ${n}   ${C.d}swap${C.x} : ${swapN}x ${swapAmt} ETH   ${C.d}vault${C.x} : ${vaultAmt} ETH`));
    console.log(row(`${C.d}stake${C.x} : ${stakeAmt}   ${C.d}reset${C.x} : 00:00 UTC`));
    console.log(`${C.b}╚${"═".repeat(W)}╝${C.x}`);
    console.log(`  ${C.d}${new Date().toISOString()}${C.x}\n`);
  },
  summary(rows, swapTarget) {
    console.log(`\n${C.B}── RINGKASAN HARI INI ──────────────────────────────────────────${C.x}`);
    console.log(`${C.d}  wallet                checkin  vault  swap        stake   AP     catatan${C.x}`);
    for (const r of rows) {
      const mark = (b) => (b ? `${C.g}✓${C.x}` : `${C.r}✗${C.x}`);
      const swapStr = r.swaps >= swapTarget ? `${C.g}${r.swaps}/${swapTarget}${C.x}` : r.swaps > 0 ? `${C.y}${r.swaps}/${swapTarget}${C.x}` : `${C.r}0/${swapTarget}${C.x}`;
      const ap = r.ap == null ? `${C.d}?${C.x}` : `${C.g}${r.ap}${C.x}`;
      const note = r.notes?.length ? trunc(r.notes[0], 40) : r.pending ? `${C.y}${r.pending} pending verify${C.x}` : "";
      console.log(`  ${pad(`#${r.index} ${r.address.slice(0, 8)}…`, 20)} ${pad(mark(r.checkin), 8)} ${pad(mark(r.vault), 7)} ${pad(swapStr, 12)} ${pad(mark(r.stake), 8)} ${pad(ap, 7)} ${note}`);
    }
    console.log(`${C.d}  ✓ = diterima server (AP masuk) · ✗ = belum · pending = tx sukses, verify menyusul${C.x}\n`);
  },
};

export const tag = { err: (s) => `${C.r}${s}${C.x}` };
