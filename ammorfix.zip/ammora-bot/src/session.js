import { log, nextUtcMidnight, todayUTC } from "./misc.js";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export { sleep, log, nextUtcMidnight, todayUTC };

const API_URL = process.env.API_URL || "https://ammora.org/api/waitlist/season2";
const ORIGIN = "https://ammora.org";
const CHAIN_ID = 91342;
const POLICY = "season2-2026-11-16";

export class AmmoraSession {
  constructor(wallet) {
    this.wallet = wallet;
    this.cookie = {};
  }
  buildMessage(action, payload, nonce, issuedAt) {
    return [
      "Ammora Season 2 action",
      `Origin: ${ORIGIN}`,
      `Chain: ${CHAIN_ID}`,
      `Wallet: ${this.wallet.address.toLowerCase()}`,
      `Action: ${action}`,
      `Payload: ${payload}`,
      `Nonce: ${nonce}`,
      `Issued at: ${issuedAt}`,
      `Policy: ${POLICY}`,
    ].join("\n");
  }
  cookieHeader() {
    return Object.entries(this.cookie ?? {}).map(([k, v]) => `${k}=${v}`).join("; ");
  }
  saveCookies(res) {
    const raw = res.headers.getSetCookie?.() ?? [];
    for (const line of raw) {
      const [pair] = line.split(";");
      const i = pair.indexOf("=");
      if (i > 0) this.cookie[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
    }
  }
  async rawCall(body) {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        origin: ORIGIN,
        referer: ORIGIN + "/",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
        ...(Object.keys(this.cookie).length ? { cookie: this.cookieHeader() } : {}),
      },
      body: JSON.stringify(body),
    });
    this.saveCookies(res);
    let json = null;
    try { json = await res.json(); } catch {}
    return { ok: res.ok, status: res.status, json };
  }
  /* Signed action. Menangani challenge SEASON2_SESSION_REQUIRED dengan sign ulang. */
  async action(action, payloadObj = {}, opts = {}) {
    const payload = JSON.stringify(payloadObj);
    const nonce =
      crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
    let body = { wallet: this.wallet.address, action, payload, nonce, issuedAt: Date.now() };
    let r = await this.rawCall(body);
    if (!r.ok && r.json?.error === "SEASON2_SESSION_REQUIRED" && r.json.challenge) {
      const ch = r.json.challenge;
      if (typeof ch.issuedAt === "number") {
        body.issuedAt = ch.issuedAt;
        const msg = this.buildMessage(action, payload, nonce, ch.issuedAt);
        const signature = await this.wallet.signMessage(msg);
        r = await this.rawCall({ ...body, signature });
      }
    }
    if (!r.ok && !opts.allowFail) {
      const code = r.json?.error ?? `HTTP ${r.status}`;
      const err = new Error(`${action}: ${code} — ${r.json?.message ?? ""}`);
      err.code = code;
      throw err;
    }
    return r.json ?? {};
  }
  async state() {
    return this.action("state", {});
  }
}
