#!/usr/bin/env node
/**
 * Ammora Season 2 — Daily Bot (multi wallet) v3
 *
 * Misi harian otomatis (reset 00:00 UTC):
 *   1. Check in                 (+100 AP)
 *   2. GIWA ETH Vault 0.01 ETH  (+50 AP)
 *   3. Complete swaps x5        (+20 AP / swap)
 *   4. Stake $tAMM              (+100 AP)
 * X-post / verify / follow dibiarkan manual.
 *
 * Perbaikan v3:
 *  - Hash yang tx-nya sukses tapi VERIFIKASI server gagal disimpan di state.json
 *    dan di-verify ULANG di run berikutnya (tanpa kirim tx baru = tanpa buang ETH).
 *  - Jumlah swap dihitung dari yang TERVERIFIKASI server, bukan dari tx terkirim.
 *  - Tunggu konfirmasi lebih dalam sebelum verify (server butuh tx ter-index).
 *  - Tampilan berwarna + tabel ringkasan.
 *
 * Jalankan:  npm start          (sekali jalan)
 *            npm run loop       (otomatis tiap hari setelah 00:00 UTC)
 *            FORCE=1 npm start  (abaikan catatan selesai & verify ulang semuanya)
 */
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { JsonRpcProvider, Wallet, Contract, Interface, parseEther, parseUnits, formatEther, formatUnits, MaxUint256 } from "ethers";
import { AmmoraSession } from "./session.js";
import { sleep, nextUtcMidnight, todayUTC } from "./misc.js";
import { ui, tag } from "./ui.js";

/* ---------- kontrak fallback; disamakan dgn API state saat runtime ---------- */
const VAULT_FALLBACK = "0x016e6B1c6e73152eA8C33CDA7D960D08608f7c4b";
const IFACE_VAULT = new Interface(["function deposit() payable"]);
const IFACE_ROUTER = new Interface([
  "function swapPoolExactInNative(address pool,uint256 minimumAmountOut,address recipient,uint256 deadline,address referrer) payable",
  "function buySourceExactInNative(address factory,address curve,uint256 minimumAmountOut,bool allowPartialFill,address recipient,uint256 deadline,address referrer) payable",
]);
const IFACE_CURVE = new Interface([
  "function status() view returns (uint8)",
  "function canonicalPool() view returns (address)",
  "function quoteExactInput(uint256,bool) view returns ((uint256 amountIn,uint256 amountOut,uint256 amountLeft)[])",
]);
const IFACE_V5F = new Interface(["function isPool(address) view returns (bool)"]);
const IFACE_V5POOL = new Interface(["function quoteExactIn(address,uint256) view returns (uint256)"]);
const IFACE_STAKING = new Interface(["function deposit(uint256)"]);
const IFACE_IDENTITY = new Interface([
  "function owner() view returns(address)",
  "function eligible(address) view returns(bool)",
  "function authorizationVersion() view returns(uint8)",
  "function registerAuthorized(address,bytes32,uint64,bytes)",
]);
const IFACE_ERC20 = new Interface([
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address,address) view returns (uint256)",
  "function approve(address,uint256) returns (bool)",
]);

/* ---------- config ---------- */
const RPC = process.env.RPC_URL || "https://sepolia-rpc.giwa.io/";
const SWAP_TARGET = Number(process.env.SWAP_COUNT || 5);
const SWAP_AMOUNT_ETH = process.env.SWAP_AMOUNT_ETH || "0.0005";
const VAULT_AMOUNT_ETH = process.env.VAULT_AMOUNT_ETH || "0.01";
const STAKE_AMOUNT = (process.env.STAKE_AMOUNT || "all").toLowerCase();
const SLIPPAGE_PCT = Number(process.env.SLIPPAGE_PCT || 1);
const FORCE = process.env.FORCE === "1";
const CONFIRM_DEPTH = Number(process.env.CONFIRM_DEPTH || 13); // web resmi nunggu 12-13 konfirmasi sebelum verify

/* ---------- state harian ---------- */
const STATE_FILE = path.join(process.cwd(), "data", "state.json");
let _state = null;
function st() {
  if (_state === null) { try { _state = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); } catch { _state = {}; } }
  return _state;
}
function persist() { fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(_state, null, 2)); }
function dayState(addr) {
  const w = (st()[addr.toLowerCase()] ??= {});
  return (w[todayUTC()] ??= { missions: {}, pending: [], swapsVerified: 0 });
}

/* ---------- wallets ---------- */
const keys = [];
for (let i = 1; i <= 100; i++) {
  const k = process.env[`PRIVATE_KEY_${i}`];
  if (k && k.trim()) keys.push(k.trim());
}
if (!keys.length) {
  console.error(tag.err("Tidak ada PRIVATE_KEY_1..N di .env — lihat .env.example"));
  process.exit(1);
}
const provider = new JsonRpcProvider(RPC, { chainId: 91342, name: "giwa-sepolia" }, { staticNetwork: true });
const wallets = keys.map((k, i) => ({ index: i + 1, address: new Wallet(k).address }));
ui.banner(keys.length, SWAP_TARGET, SWAP_AMOUNT_ETH, VAULT_AMOUNT_ETH, STAKE_AMOUNT);

/* ---------- helpers ---------- */
async function sendTx(wallet, tx, label) {
  let gas;
  try { gas = await provider.estimateGas({ ...tx, from: wallet.address }); }
  catch (e) { throw new Error(`${label}: estimateGas gagal — ${(e.shortMessage ?? e.message).slice(0, 160)}`); }
  const fee = await provider.getFeeData();
  const resp = await wallet.sendTransaction({
    ...tx, gasLimit: gas,
    ...(fee.maxFeePerGas ? { maxFeePerGas: fee.maxFeePerGas * 2n, maxPriorityFeePerGas: fee.maxPriorityFeePerGas ?? 1n } : {}),
  });
  ui.tx(label, resp.hash);
  const rec = await resp.wait(1, 180_000);
  if (!rec || rec.status !== 1) throw new Error(`${label}: reverted (${resp.hash})`);
  return rec;
}

/** tunggu tx final (13 konfirmasi, seperti web resmi) sebelum verify */
async function waitDepth(recHash, label) {
  const deadline = Date.now() + 300_000;
  let rec = null;
  while (Date.now() < deadline) {
    rec = await provider.getTransactionReceipt(recHash).catch(() => null);
    if (rec) {
      const head = await provider.getBlockNumber().catch(() => 0);
      if (head - rec.blockNumber >= CONFIRM_DEPTH) return rec;
    }
    await sleep(5000);
  }
  return rec; // verify tetap dicoba & di-retry kalau depth belum tercapai
}

/**
 * verify-transaction dengan retry tuntas (12 percobaan, backoff).
 * Return { ok: true } bila server terima; { ok: false, code, message } kalau gagal final.
 */
async function verifyMission(session, mission, hash, L, label) {
  const retriable = ["TRANSACTION_NOT_FINAL", "VERIFIER_UNAVAILABLE", "VERIFICATION_BUSY", "RATE_LIMITED", "SERVICE_UNAVAILABLE", "TIMEOUT"];
  for (let attempt = 1; attempt <= 12; attempt++) {
    let r;
    try {
      r = await session.action("verify-transaction", { mission, hash }, { allowFail: true });
    } catch (e) {
      r = { error: e.code ?? "EXCEPTION", message: e.message };
    }
    if (!r?.error) {
      ui.verifyOk(label, attempt, r);
      return { ok: true };
    }
    ui.verifyFail(label, attempt, r.error, r.message);
    if (retriable.includes(r.error) && attempt < 12) { await sleep(20_000); continue; }
    if (["ALREADY_VERIFIED", "ACTION_ALREADY_USED"].includes(r.error)) return { ok: true, already: true };
    return { ok: false, code: r.error, message: r.message ?? "" };
  }
  return { ok: false, code: "TIMEOUT", message: "verify tidak kunjung sukses" };
}

async function fetchConfig(session) {
  const st = await session.state();
  const c = st.contracts ?? {};
  const sw = st.swap ?? {};
  if (!sw.nativeRouter || !sw.curve || !c.token || !c.staking)
    throw new Error("API state tidak lengkap — season mungkin sedang tutup.");
  return {
    token: c.token, staking: c.staking, vault: VAULT_FALLBACK, identity: c.identity,
    router: sw.nativeRouter, curve: sw.curve, launchFactory: sw.launchFactory,
    v5Factory: sw.v5Factory, weth: sw.weth, tokenDecimals: Number(sw.tokenDecimals ?? 6),
  };
}

/**
 * Aktivasi identity (wajib sebelum stake — kalau tidak, deposit di kontrak
 * staking REVERT). Alur sama dgn web: cek eligible() → kalau belum, minta
 * authorization ke server (identity-authorization) → kirim tx registerAuthorized.
 */
async function ensureIdentity(session, entry, wallet, cfg, L) {
  if (!cfg.identity || cfg.identity === "0x0000000000000000000000000000000000000000") return true;
  const idc = new Contract(cfg.identity, IFACE_IDENTITY, provider);
  if (await idc.eligible(entry.address)) return true;
  L(ui.warn("wallet belum identity-eligible — mengaktifkan (wajib untuk stake)…"));
  const owner = (await idc.owner()).toLowerCase();
  const ver = Number(await idc.authorizationVersion());
  if (owner !== "0x13cd27a6e337097db858c9c4fa472fbad2f2c637" || ver !== 1)
    throw new Error("identity: kontrak owner/version tidak sesuai setup resmi — skip aktivasi otomatis");
  const r = await session.action("identity-authorization", {});
  if (r?.status !== "authorized")
    throw new Error(`identity-authorization: respons tak terduga ${JSON.stringify(r).slice(0, 160)}`);
  if ((r.wallet ?? "").toLowerCase() !== entry.address.toLowerCase() || (r.contract ?? "").toLowerCase() !== cfg.identity.toLowerCase())
    throw new Error("identity-authorization: wallet/contract tidak cocok");
  L("identity: mengirim registerAuthorized…");
  const rec = await sendTx(wallet, {
    to: cfg.identity,
    data: IFACE_IDENTITY.encodeFunctionData("registerAuthorized", [entry.address, r.participant, BigInt(r.deadline), r.signature]),
  }, "identity-activate");
  await waitDepth(rec.hash, "identity-activate");
  // verify eligible (server-side tx butuh beberapa detik)
  for (let i = 0; i < 10; i++) {
    try { if (await idc.eligible(entry.address)) { L(ui.ok("identity eligible ✔")); return true; } } catch {}
    await sleep(5000);
  }
  throw new Error("identity: masih belum eligible setelah aktivasi");
}

/* ---------- re-verify pending (tx sukses tapi AP belum masuk) ---------- */
async function flushPending(session, entry, L) {
  const d = dayState(entry.address);
  if (!d.pending?.length) return;
  L(ui.warn(`ada ${d.pending.length} tx lama yang belum terverifikasi — di-verify ulang (tanpa tx baru)`));
  const still = [];
  for (const p of d.pending) {
    const res = await verifyMission(session, p.mission, p.hash, L, `${p.mission} (re)`);
    if (res.ok) { if (p.mission === "swap") { d.swapsVerified = Math.min(SWAP_TARGET, d.swapsVerified + 1); persist(); } }
    else still.push(p);
  }
  d.pending = still;
  persist();
}

/* ---------- daily run per wallet ---------- */
async function runWallet(entry, key) {
  const wallet = new Wallet(key, provider);
  wallet._idx = entry.index;
  const session = new AmmoraSession(wallet);
  const L = (...a) => console.log(`${ui.walletTag(entry)} ${a.join(" ")}`);
  const markMission = (what) => { dayState(entry.address).missions[what] = true; persist(); };
  const isDone = (what) => !FORCE && dayState(entry.address).missions[what] === true;
  const ALREADY = ["ACTION_ALREADY_USED", "ALREADY_SUBMITTED", "INVALID_MISSION", "ALREADY_CHECKED_IN"];

  const results = { checkin: false, vault: false, swaps: 0, stake: false, ap: null, notes: [] };

  let cfg;
  try { cfg = await fetchConfig(session); } catch (e) { L(ui.err("SKIP:"), e.message); return results; }

  const st = await session.action("state", {});
  const acc = st.account ?? {};
  if (!acc.registered) { L(ui.err("SKIP: wallet belum terdaftar — daftar manual dulu di https://ammora.org/waitlist")); return results; }
  if (!acc.verified || !acc.followed) {
    const msg = "X belum verified/follow @AmmoraHQ — verify AP akan ditolak server. Selesaikan manual di web.";
    L(ui.warn(msg)); results.notes.push(msg);
  }
  results.ap = acc.ap;

  /* 0) flush pending dari run sebelumnya */
  await flushPending(session, entry, L);
  results.swaps = dayState(entry.address).swapsVerified;

  /* 1) CHECK IN */
  if (isDone("checkin")) { L(ui.dim("checkin: sudah selesai hari ini")); results.checkin = true; }
  else {
    try {
      const r = await session.action("checkin", {});
      L(ui.ok("checkin ✔"), JSON.stringify(r.status ?? "ok").slice(0, 80));
      markMission("checkin"); results.checkin = true;
    } catch (e) {
      if (ALREADY.includes(e.code)) { L(ui.dim("checkin: sudah dilakukan")); markMission("checkin"); results.checkin = true; }
      else { L(ui.err("checkin GAGAL:"), e.code ?? "", e.message); results.notes.push(`checkin: ${e.code ?? e.message}`); }
    }
  }

  /* 2) VAULT 0.01 ETH */
  if (isDone("vault")) { L(ui.dim("vault: sudah selesai hari ini")); results.vault = true; }
  else {
    const bal = await provider.getBalance(entry.address);
    const need = parseEther(VAULT_AMOUNT_ETH);
    if (bal < need + parseEther("0.0005")) {
      L(ui.err(`vault GAGAL: saldo ${formatEther(bal)} ETH < ${VAULT_AMOUNT_ETH} + gas — isi dari faucet.`));
      results.notes.push("vault: saldo kurang");
    } else {
      try {
        const rec = await sendTx(wallet, { to: cfg.vault, value: need, data: IFACE_VAULT.encodeFunctionData("deposit") }, "vault-deposit");
        await waitDepth(rec.hash, "vault");
        const res = await verifyMission(session, "vault", rec.hash, L, "vault");
        if (res.ok) { markMission("vault"); results.vault = true; }
        else {
          const d = dayState(entry.address); d.pending.push({ mission: "vault", hash: rec.hash, at: Date.now(), err: res.code }); persist();
          results.notes.push(`vault verify gagal: ${res.code} — dicoba ulang run berikutnya`);
        }
      } catch (e) { L(ui.err("vault GAGAL:"), e.message); results.notes.push(`vault: ${e.message}`); }
    }
  }

  /* 3) SWAPS sampai target TERVERIFIKASI */
  const curve = new Contract(cfg.curve, IFACE_CURVE, provider);
  let status = -1;
  try { status = Number(await curve.status()); } catch (e) { L(ui.err("curve.status GAGAL:"), (e.shortMessage ?? e.message).slice(0, 120)); }

  for (let s = results.swaps; s < SWAP_TARGET; s++) {
    const tagStr = `swap ${s + 1}/${SWAP_TARGET}`;
    try {
      const amountIn = parseEther(SWAP_AMOUNT_ETH);
      let data, value = amountIn;
      if (status === 3) {
        const pool = await curve.canonicalPool();
        const vf = new Contract(cfg.v5Factory, IFACE_V5F, provider);
        if (!(await vf.isPool(pool))) throw new Error("pool belum verified");
        const out = await new Contract(pool, IFACE_V5POOL, provider).quoteExactIn(cfg.weth, amountIn);
        if (out <= 0n) throw new Error("quote = 0 — nominal swap terlalu kecil/besar");
        const minOut = (out * BigInt(10_000 - SLIPPAGE_PCT * 100)) / 10_000n;
        data = IFACE_ROUTER.encodeFunctionData("swapPoolExactInNative", [pool, minOut, entry.address, BigInt(Math.floor(Date.now() / 1000)) + 600n, "0x0000000000000000000000000000000000000000"]);
      } else if (status === 1) {
        const quotes = await curve.quoteExactInput(amountIn, false);
        const q = quotes[quotes.length - 1];
        if (q.amountOut <= 0n) throw new Error("quote amountOut = 0");
        const minOut = (q.amountOut * BigInt(10_000 - SLIPPAGE_PCT * 100)) / 10_000n;
        data = IFACE_ROUTER.encodeFunctionData("buySourceExactInNative", [cfg.launchFactory, cfg.curve, minOut, false, entry.address, BigInt(Math.floor(Date.now() / 1000)) + 600n, "0x0000000000000000000000000000000000000000"]);
      } else throw new Error(`curve status ${status} (liquidity transition) — coba lagi nanti`);

      const rec = await sendTx(wallet, { to: cfg.router, value, data }, tagStr);
      await waitDepth(rec.hash, tagStr);
      const res = await verifyMission(session, "swap", rec.hash, L, tagStr);
      if (res.ok) {
        const d = dayState(entry.address);
        d.swapsVerified = Math.min(SWAP_TARGET, d.swapsVerified + 1);
        persist();
        results.swaps = d.swapsVerified;
      } else {
        const d = dayState(entry.address); d.pending.push({ mission: "swap", hash: rec.hash, at: Date.now(), err: res.code }); persist();
        results.notes.push(`${tagStr} verify gagal: ${res.code}`);
        await sleep(8000);
      }
      await sleep(3000 + Math.floor(Math.random() * 5000));
    } catch (e) {
      L(ui.err(tagStr, "GAGAL:"), (e.message ?? e).slice(0, 200));
      results.notes.push(`${tagStr}: ${(e.message ?? e).slice(0, 80)}`);
      if (/insufficient funds|estimateGas gagal/i.test(e.message ?? "")) break;
      await sleep(6000);
    }
  }
  const finalSwaps = dayState(entry.address);
  if (finalSwaps.pending.some((p) => p.mission === "swap"))
    L(ui.warn(`swap tersisa ${SWAP_TARGET - finalSwaps.swapsVerified} yang menunggu verify ulang — jalanin lagi besok/bentar lagi, TIDAK perlu tx baru.`));

  /* 4) STAKE tAMM */
  if (isDone("stake")) { L(ui.dim("stake: sudah selesai hari ini")); results.stake = true; }
  else {
    try {
      const tok = new Contract(cfg.token, IFACE_ERC20, provider);
      const bal = await tok.balanceOf(entry.address);
      if (bal === 0n) L(ui.dim("stake: saldo tAMM 0 — hasil swap hari ini dipakai stake besok."));
      else {
        let amount = STAKE_AMOUNT === "all" ? bal : parseUnits(String(STAKE_AMOUNT), cfg.tokenDecimals);
        if (amount > bal) amount = bal;
        /* wajib: identity eligible sebelum deposit staking, kalau tidak estimateGas REVERT */
        await ensureIdentity(session, entry, wallet, cfg, L);
        const allow = await tok.allowance(entry.address, cfg.staking);
        if (allow < amount) await sendTx(wallet, { to: cfg.token, data: IFACE_ERC20.encodeFunctionData("approve", [cfg.staking, MaxUint256]) }, "approve tAMM");
        const rec = await sendTx(wallet, { to: cfg.staking, data: IFACE_STAKING.encodeFunctionData("deposit", [amount]) }, `stake ${formatUnits(amount, cfg.tokenDecimals)} tAMM`);
        await waitDepth(rec.hash, "stake");
        const res = await verifyMission(session, "stake", rec.hash, L, "stake");
        if (res.ok) { markMission("stake"); results.stake = true; }
        else {
          const d = dayState(entry.address); d.pending.push({ mission: "stake", hash: rec.hash, at: Date.now(), err: res.code }); persist();
          results.notes.push(`stake verify gagal: ${res.code}`);
        }
      }
    } catch (e) { L(ui.err("stake GAGAL:"), (e.message ?? e).slice(0, 200)); results.notes.push(`stake: ${(e.message ?? e).slice(0, 80)}`); }
  }

  /* ringkasan AP dari server */
  try {
    const after = await session.action("state", {});
    results.ap = after.account?.ap ?? results.ap;
  } catch {}
  results.pending = dayState(entry.address).pending?.length ?? 0;
  return results;
}

/* ---------- runner ---------- */
async function runAll() {
  const summaries = [];
  for (let i = 0; i < wallets.length; i++) {
    let results;
    try { results = await runWallet(wallets[i], keys[i]); }
    catch (e) { console.log(`${ui.walletTag(wallets[i])} ${ui.err("FATAL:")}`, (e.message ?? e).slice(0, 200)); results = { checkin: false, vault: false, swaps: 0, stake: false, ap: null, pending: 0, notes: [`fatal: ${(e.message ?? e).slice(0, 60)}`] }; }
    summaries.push({ ...wallets[i], ...results });
    await sleep(4000 + Math.floor(Math.random() * 6000));
  }
  /* pass kedua: verify ulang pending yang muncul di run ini (server kadang baru index belakangan) */
  let extra = false;
  for (let i = 0; i < wallets.length; i++) {
    const d = dayState(wallets[i].address);
    if (d.pending?.length) {
      extra = true;
      console.log(`${ui.walletTag(wallets[i])} ${ui.warn(`pass-2: verify ulang ${d.pending.length} tx`)}`);
      const session = new AmmoraSession(new Wallet(keys[i], provider));
      await flushPending(session, wallets[i], (...a) => console.log(`${ui.walletTag(wallets[i])} ${a.join(" ")}`));
      const d2 = dayState(wallets[i].address);
      summaries[i].pending = d2.pending.length;
      summaries[i].swaps = d2.swapsVerified;
    }
    await sleep(2000);
  }
  ui.summary(summaries, SWAP_TARGET);
  console.log(ui.dim(`===== selesai ${new Date().toISOString()} =====`));
  return summaries;
}

/** apakah masih ada yang bisa dipulihkan hari ini (pending verify / swap kurang dari target) */
function recoverable(summaries) {
  return summaries.some((r) => (r.pending ?? 0) > 0 || (r.swaps ?? 0) < SWAP_TARGET);
}

if (process.argv.includes("--loop")) {
  console.log(ui.warn("Mode loop: run tiap hari setelah 00:00 UTC + cek ulang 30 menit sekali selama masih ada pending verify / swap belum full. Ctrl+C untuk berhenti."));
  while (true) {
    const summaries = await runAll();
    if (recoverable(summaries)) {
      console.log(ui.warn("Masih ada yang belum terverifikasi penuh — cek ulang otomatis 30 menit lagi (verify ulang tanpa tx baru)."));
      await sleep(30 * 60 * 1000);
    } else {
      const next = nextUtcMidnight();
      console.log(ui.dim(`Daily lengkap. Run berikutnya: ${new Date(next).toISOString()}`));
      await sleep(next - Date.now());
    }
  }
} else {
  await runAll();
}
