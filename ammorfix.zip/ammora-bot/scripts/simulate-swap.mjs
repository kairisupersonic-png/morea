import { Contract, JsonRpcProvider, Interface, parseEther } from "ethers";
const p = new JsonRpcProvider("https://sepolia-rpc.giwa.io/", { chainId: 91342, name: "giwa" }, { staticNetwork: true });
const curve = "0x1FD82a1BeAff168BdeFC790EB0f1A50f7C53b978";
const v5f = "0xC0Fc168DeD39DA53C11D5082D9303216C3c37375";
const weth = "0x4200000000000000000000000000000000000006";
const router = "0x4FC91b90087288520A7bB4aA7Ab5441bb4E9C496";
const who = process.env.WHO || "0x2895FF2286A610FE63c6412FCf2D46127439FA68";
const curveC = new Contract(curve, ["function canonicalPool() view returns (address)"], p);
const pool = await curveC.canonicalPool();
const poolC = new Contract(pool, ["function quoteExactIn(address,uint256) view returns (uint256)"], p);
const amountIn = parseEther(process.env.AMT || "0.0005");
const out = await poolC.quoteExactIn(weth, amountIn);
const minOut = (out * 99n) / 100n;
const I = new Interface(["function swapPoolExactInNative(address,uint256,address,uint256,address) payable"]);
const data = I.encodeFunctionData("swapPoolExactInNative", [pool, minOut, who, BigInt(Math.floor(Date.now() / 1000)) + 600n, "0x0000000000000000000000000000000000000000"]);
console.log("amountIn", amountIn.toString(), "quote", out.toString(), "minOut", minOut.toString());
try {
  const r = await p.call({ from: who, to: router, data, value: amountIn });
  console.log("SIMULASI SUKSES ✔ return:", r.slice(0, 80));
} catch (e) { console.log("simulasi revert:", (e.revert?.args ?? e.shortMessage ?? e.message).toString().slice(0, 200)); }
