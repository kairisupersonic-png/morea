#!/usr/bin/env node
/**
 * Diagnosa: cek ulang satu transaksi ke server Ammora + cetak respons lengkap.
 *
 * Pakai:
 *   node scripts/verify-tx.mjs <PRIVATE_KEY> <mission> <txhash>
 *   mission = swap | vault | stake
 *
 * Contoh:
 *   node scripts/verify-tx.mjs 0xabc... stake 0x1234...
 *
 * Script ini TIDAK mengirim transaksi apa pun — cuma sign pesan sesi & panggil verify.
 */
import { JsonRpcProvider, Wallet } from "ethers";
import { AmmoraSession } from "../src/session.js";

const [pk, mission, hash] = process.argv.slice(2);
if (!pk || !mission || !hash) {
  console.log("Usage: node scripts/verify-tx.mjs <PRIVATE_KEY> <swap|vault|stake> <txhash>");
  process.exit(1);
}
const provider = new JsonRpcProvider(process.env.RPC_URL || "https://sepolia-rpc.giwa.io/", { chainId: 91342, name: "giwa-sepolia" }, { staticNetwork: true });
const wallet = new Wallet(pk, provider);
const session = new AmmoraSession(wallet);

console.log("wallet:", wallet.address);

const rec = await provider.getTransactionReceipt(hash).catch(() => null);
if (!rec) console.log("PERINGATAN: receipt tidak ditemukan — tx mungkin belum final / hash salah.");
else console.log(`tx: status=${rec.status} block=${rec.blockNumber} to=${rec.to} logs=${rec.logs.length}`);

const st = await session.action("state", {});
const a = st.account ?? {};
console.log(`account: registered=${a.registered} verified=${a.verified} followed=${a.followed} ap=${a.ap}`);

for (let i = 1; i <= 3; i++) {
  const r = await session.action("verify-transaction", { mission, hash }, { allowFail: true });
  console.log(`\nverify attempt ${i}:`, JSON.stringify(r, null, 1).slice(0, 1500));
  if (!r?.error) break;
  if (!["TRANSACTION_NOT_FINAL", "VERIFIER_UNAVAILABLE", "VERIFICATION_BUSY"].includes(r.error)) break;
  await new Promise((r2) => setTimeout(r2, 10000));
}

const after = await session.action("state", {});
console.log("\nsetelah verify: ap =", after.account?.ap);
