# Ammora Season 2 — Daily Bot (Multi Wallet)

Bot harian untuk misi **Ammora Season 2** (GIWA Sepolia testnet, chain 91342):

| Misi | AP | Otomatis |
|---|---|---|
| Check in | +100 | ✅ |
| GIWA ETH Vault (transfer 0.01 ETH) | +50 | ✅ |
| Complete swaps 5x | +20/swap | ✅ |
| Stake $tAMM | +100 | ✅ |
| Verify X / Follow @AmmoraHQ / Weekly X post / dll | — | ❌ manual (pakai browser) |

## Alur yang dipakai bot (sama seperti web resmi)
1. **Check in** → POST `ammora.org/api/waitlist/season2` action `checkin`, pakai signature
   pesan `Ammora Season 2 action ... Policy: season2-2026-11-16` (EIP-191) saat server
   minta challenge session.
2. **Vault** → kirim `deposit()` + 0.01 ETH ke vault `0x016e6B1c...7c4b`, lalu
   `verify-transaction {mission:"vault", hash}`.
3. **Swap 5x** → baca `curve.status()`; kalau sudah graduated (status 3): quote
   `pool.quoteExactIn(WETH, amountIn)` lalu `swapPoolExactInNative(pool, minOut, you,
   deadline, 0x0)` ke router native. Kalau masih curve (status 1): `buySourceExactInNative(...)`.
4. **Stake** → `approve(staking, max)` lalu `staking.deposit(amount)`; tAMM decimals = 6.
5. Semua tx diverifikasi ke server pakai `verify-transaction` supaya AP masuk.

Alamat kontrak selalu di-refresh dari API `state` tiap run, jadi kalau tim Ammora ganti
kontrak bot tetap jalan (vault tetap fallback ke alamat vault resmi).

## Setup

Butuh **Node.js 18+** (download: https://nodejs.org).

```
# 1. Install dependensi
npm install

# 2. Isi file .env (copy dari .env.example)
cp .env.example .env      # Windows: copy .env.example .env
```

### Isi .env (1 akun = 1 baris, multi wallet tinggal tambah baris)

```
PRIVATE_KEY_1=0x...private key wallet akun 1...
PRIVATE_KEY_2=0x...private key wallet 2...
PRIVATE_KEY_3=0x...
SWAP_COUNT=5
SWAP_AMOUNT_ETH=0.0005
VAULT_AMOUNT_ETH=0.01
STAKE_AMOUNT=all
```

⚠️ **Private key = akses penuh wallet.** Pakai wallet khusus farming, jangan wallet utama.
File `.env` jangan dibagikan/di-upload ke mana pun. Bot ini lokal 100%, tidak mengirim
private key ke server mana pun — hanya signature pesan sesi (bukan transaksi approval).

## Jalankan

```
npm start        # jalan sekali untuk semua wallet lalu selesai
npm run loop     # jalan terus: tiap hari setelah reset 00:00 UTC (plus jitter acak)
FORCE=1 npm start   # paksa jalankan lagi walau state.json bilang sudah selesai hari ini
```

## Jadwal
Misi harian reset **00:00 UTC** (situs menampilkan countdown "Resets in ..."). Mode
`npm run loop` otomatis tidur sampai 00:01 UTC + jitter acak lalu jalan lagi.

## Prasyarat per wallet
- Wallet **sudah terdaftar** + X verified (sekali saja, manual di web).
- Saldo GIWA Sepolia ETH cukup: ±0.011 ETH/hari (0.01 vault + 5 swap 0.0005 + gas).
  Faucet: https://faucet.giwa.io/ atau https://faucet.nodit.io/
- Saldo tAMM untuk stake (hasil swap bot bisa dipakai untuk besok).

## Catatan
- `data/state.json` menyimpan progres harian supaya tidak dobel jalan.
- Bila ada error `AUTOMATION_DETECTED` / rate limit, bot akan skip dan coba besok —
  jeda antar wallet & antar swap sudah diberi delay acak.
- Log semua tx hash tercetak di console.
